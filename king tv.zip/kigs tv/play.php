
<!DOCTYPE html>
<html>
<head>
<meta name="propeller" content="2f2d2111ab466fcf1ed963065a2a89fd">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>King TV</title>
<style>
.ak {
  font: bold 11px Arial;
  text-decoration: none;
  background-color: #EEEEEE;
  color: #333333;
  padding: 2px 6px 2px 6px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC;
}
</style>
<body>





</html>
<!DOCTYPE html>
<html>
<head>
<meta content='width=device-width,minimum-scale=1,initial-scale=1' name='viewport'/>
<link rel="stylesheet" href="https://cdn.plyr.io/3.6.2/plyr.css" />
<link href="https://fonts.googleapis.com/css?family=Poppins|Quattrocento+Sans" rel="stylesheet"/>
<script src="https://cdn.plyr.io/3.6.3/plyr.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hls.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="assets/js/hide-banner.js"></script>

<style>
html {
  font-family: Poppins;
  background: #000;
  margin: 0;
  padding: 0
}

.loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #000;
        z-index: 9999;
    }
    
    .loading-text {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        text-align: center;
        width: 100%;
        height: 100px;
        line-height: 100px;
    }
    
    .loading-text span {
        display: inline-block;
        margin: 0 5px;
        color: #00b3ff;
        font-family: 'Quattrocento Sans', sans-serif;
    }
    
    .loading-text span:nth-child(1) {
        filter: blur(0px);
        animation: blur-text 1.5s 0s infinite linear alternate;
    }
    
    .loading-text span:nth-child(2) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.2s infinite linear alternate;
    }
    
    .loading-text span:nth-child(3) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.4s infinite linear alternate;
    }
    
    .loading-text span:nth-child(4) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.6s infinite linear alternate;
    }
    
    .loading-text span:nth-child(5) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.8s infinite linear alternate;
    }
    
    .loading-text span:nth-child(6) {
        filter: blur(0px);
        animation: blur-text 1.5s 1s infinite linear alternate;
    }
    
    .loading-text span:nth-child(7) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.2s infinite linear alternate;
    }
        .loading-text span:nth-child(8) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.2s infinite linear alternate;
    }
        .loading-text span:nth-child(9) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.2s infinite linear alternate;
    }
        .loading-text span:nth-child(10) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.2s infinite linear alternate;
    }

    
    @keyframes blur-text {
        0% {
            filter: blur(0px);
        }
        100% {
            filter: blur(4px);
        }
    }

    .plyr__video-wrapper::before {
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 10;
        content: '';
        height: 35px;
        width: 35px;
background: url('') no-repeat;
        background-size: 35px auto, auto;
    }

    .plyr__video-wrapper::after {
        position: absolute;
        top: 15px;
        left: 15px;
        z-index: 10;
        content: '';
        height: 35px;
        width: 35px;
        background: url('') no-repeat;
        background-size: 35px auto, auto;
    }

</style>




</head>
<body class='index'>
<div class='chplayer'>
<div class='site-link'></div>
<div class='videos-channel'>
<a class='button refresh' href='javascript:window.location.reload()'>تحديث</a>
<div id='showshare' style='display: block;' title='مشاركة'><span href='javascript:void(0)' onclick='document.getElementById("showother").style.display="block";document.getElementById("showshare").style.display="none"'><div class='button share'>مشاركة</div></span></div>
<div class='showother' id='showother' style='display: none;'><span href='javascript:void(0)' onclick='document.getElementById("showother").style.display=&#39;none&#39;;document.getElementById("showshare").style.display="block"' title='إغلاق'><div class='button close'>إغلاق</div></span><div id='share_channel'><div class='share-channel'>
</div></div></div>
</div>
</div>


<style>/*<![CDATA[*/ body{background:#000;font-family:sans-serif;margin:0} *{text-decoration:none} .videos-channel{position:absolute;z-index:999;left:10px;top:10px;right:10px;height:0} .videos-channel .button{background:#552a86;cursor:pointer;font-size:14px;float:left;display:block;border-radius:4px;height:25px;text-align:center;line-height:22px;text-shadow:0 1px 1px #000;color:#fff;padding:0 10px;font-family:sans-serif;font-weight:bold;position:relative;z-index:99} .videos-channel .refresh{float:right} #share_channel{position:absolute;top:-10px;z-index:9;left:-10px;border-radius:0;background:rgba(0,0,0,0.69);right:-10px;bottom:0;height:100vh;text-align:center} .share-channel{position:absolute;top:50%;right:0;left:0;margin-top:-50px} .share-channel textarea{margin-top:20px;border-radius:4px;border:0;max-width:350px;width:100%;direction:ltr;height:45px;overflow:hidden;font-size:11px;} .site-link{text-shadow:2px 2px 2px #000;z-index:1;bottom:18%;position:fixed;width:100%;height:0%;text-align:center;color:#fff;font-size:2vw;display:none1} .jw-controls.jw-reseth:before{content:'';z-index:9;position:absolute;right:0;left:0;bottom:7%;font-family:sans-serif;color:#fff;text-align:center;text-shadow:2px 2px 2px #000;font-size:2vw} #player{position:absolute;height:100%!important;z-index:9;right:0;left:0;} .jw-slider-time.jw-background-color.jw-reset.jw-slider-horizontal.jw-reset,.jwplayer.jw-flag-rightclick-open .jw-rightclick,.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-rewind,.jw-icon.jw-icon-inline.jw-text.jw-reset.jw-text-elapsed,.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-cc.jw-settings-submenu-button.jw-off .jw-svg-icon,.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-cc.jw-settings-submenu-button.jw-off .jw-reset-text.jw-tooltip.jw-tooltip-captions,#matchpsho,.postimg,.post-body p{display:none!important} /*.jw-error-text.jw-reset-text,body .jwplayer.jw-state-error .jw-error-msg .jw-icon{display:none!important} .jw-preview.jw-reset{background-color:#000!important;} .jw-error-msg.jw-info-overlay.jw-reset:before{content:"في حالة توقف القناة اضغط على زرار تحديث";font-family:sans-serif;}*/ .jw-text-live::before{height:6px;width:6px;background-color:#f00} .jw-text-live.jw-dvr-live{box-shadow:initial} .jw-text-live.jw-dvr-live::before{background-color:currentColor;} 

iframe.cf{position:absolute;height:40%} .cf.videoif,{z-index:99;} 

iframe.videoif{height:40%;position:absolute} 

@media screen and (max-width:500px){ .jw-controls.jw-reset:before{font-size:4vw} } .plyr { position: unset !important; } .play-wrapper svg { width: 40px !important; } .player-poster[data-poster] { background-size: 100% !important; } div#Blog1 { float: right; width: 100%; height: 100%; } .video-b { height: 100%; float: right; width: 100%; } .video-p { height: 100%; float: right; width: 100%; } div#watch_dl { height: 100%; float: right; width: 100%; } .clear-post-body { height: 100%; float: right; width: 100%; } article.post.hentry { height: 100%; float: right; width: 100%; } .posts-wrapper { height: 100%; float: right; width: 100%; } body#body { height: 100%; float: right; width: 100%; } a.asfarx { left: 0; padding: 3px; position: fixed; top: 3px; z-index: 99; background: #F44336; border: unset; border-radius: 4px; color: #fff; font-size: 11px; padding: 4px; font-family: tahoma; line-height: 10px; height: 20px; } button#roload:before, button#roload:after { position: absolute; left: 48%; top: 46%; transform: translateX(-50%) translateY(-50%); width: 55px; height: 30px; display: block; } button#roload:before { z-index: 0; background: #ff00007a; animation: pulse-border 1.5s ease-out infinite; border-radius: 5px; } button#roload:after { z-index: 1; border-radius: 5px; transition: all .2s; } @keyframes pulse-border { 0% { transform: translateX(-50%) translateY(-50%) translateZ(0) scale(1); opacity: 1 } 100% { transform: translateX(-50%) translateY(-50%) translateZ(0) scale(1.5); opacity: 0 } } .fxr { z-index: 199px; } .aslc { z-index: 1; } .fxl { z-index: 10; } .aslc { position: fixed; top: 5px; font-size: smaller; left: 0; color: #fff; z-index: 9999; width: 100%; text-align: center; } div#closeads { position: absolute; top: -30px; right: 0; color: #E91E63; } video { position: relative; } a.embed { position: absolute; top: 6px; left: 4px; } a.embed { position: fixed; top: 0; left: 4px; } body { margin: 0 !important; } button.plyr__control[data-plyr="fullscreen"] { } .plyr { border-radius: 4px; margin-bottom: 15px; } .container { margin: 20px auto; max-width: 560px; text-align: center; } .container .plyr__control--overlaid { padding: 30px; background: rgba(205, 36, 47, 0.8); } .container .plyr__control--overlaid:hover { background: #cd242f !important; } .container .plyr__control:hover { background: #cd242f !important; } .container .plyr__volume input, .container .plyr__progress input { color: #cd242f !important; } .fxl { position: fixed; left: 4px; top: 3px; z-index: 99; background: #F44336; border: navajowhite; border-radius: 4px; color: #fff; font-size: 11px; padding: 4px; } .fxr { position: fixed; right: 4px; top: 3px; z-index: 99; background: #F44336; border: navajowhite; border-radius: 4px; color: #fff; font-size: 11px; padding: 4px; } 
.video-con { display: grid; width: 100%; height: 100%; } 
.plyr__video-wrapper { height: 100% !important; width: 100% !important; } 
.container { width: 100% !important; max-width: 100% !important; height: 100% !important; } 
.plyr { margin: 0 !important; height: 100% !important; width: 100% !important; border-radius: 0 !important; } video { height: 100% !important; width: 100% !important; float: right; } div#player { width: 100% !important; height: 100% !important; } 
.ads { overflow: hidden; } div#main { float: right; width: 100%; height: 100%; } 
div#Blog1 { height: 100%; width: 100%; } html, body { height: 100%; width: 100%; } 
.player-container 
{ width: 80%; height: 40%; } video { object-fit: contain; } /*]]>*/</style>
<meta content='no-referrer' name='referrer'/>
<script async='async' charset='utf-8' src='https://platform.twitter.com/widgets.js'></script>
<style> a.button.refresh, .button.share { display: none; }</style>

<style>
.logo-container {
                position: absolute;
                top: 1px;
                left: 0px;
                width: 15px;
                height: 15px;
            }

            #logo {
                position: fixed;
                background-image: url("https://i.ibb.co/HtHXQkx/IMG-20220613-155528-854.jpg");
                background-size: cover;
                background-position: center;
            }
	  .plyr {
                height: 100%;
                width: 100%;
            }
.float {
                height: 50px;
                width: 50px;
                z-index: 10;
                border-radius: 30px;
                box-shadow: 2px 2px 3px #999;
            }
.label-container{
	            position: relative;
                top: 5px;
                left:70px;
                display:table;
                visibility: hidden;
            }

            .label-text{
                color:#FFF;
                background:rgba(51,51,51,0.5);
                display:table-cell;
                vertical-align:middle;
                padding:10px;
                border-radius:3px;
            }

            .label-arrow{
                display:table-cell;
                vertical-align:middle;
                color:#333;
                opacity:0.5;
                transform: scaleX(-1);
            }

            a.float + div.label-container {
              visibility: hidden;
              opacity: 0;
              transition: visibility 0s, opacity 0.5s ease;
            }

            a.float:hover + div.label-container{
              visibility: visible;
              opacity: 1;
            }
</style>
  <div id="loading" class="loading">
<div class="loading-text">
<span class="loading-text-words">K</span>
<span class="loading-text-words">I</span>
<span class="loading-text-words">N</span>
<span class="loading-text-words">G</span>
<span class="loading-text-words">-</span>
<span class="loading-text-words">T</span>
<span class="loading-text-words">V</span>



</div>
</div>
<div class="logo-container">
 <a href="https://t.me/pjnipl" target="_blank" rel="noopener noreferrer" class="float" id="logo"></a>
            <div class="label-container">
                <i class="fa fa-play label-arrow"></i>
                <div class="label-text">King TV</div>
            </div>
        </div>


<video controls='' autoplay height='198' poster="https://akamaividz.zee5.com/resources/<?php echo $_REQUEST["c"]; ?>/list/270x152/tv9bharatvarshb1170356ea81326334d6dab31d2cb3f9e25fe.jpg"  id='svideo' width='352'>
<source src='http://ranapkz5.1.mywebsites.link/z5ranapk.php?c=<?php echo $_REQUEST["c"]; ?>' type='application/x-mpegURL'></source>Play only On Chrome Browser
</video>

<script>
var myliveurl ="http://ranapk-star7.de1.bitmana.io/playx.php?id=<?php echo $_REQUEST["id"]; ?>&e=.m3u8";
</script>

     









 <script>
  setTimeout(videovisible, 3000)
function videovisible() {
    document.getElementById('loading').style.display = 'none'
}

</script>









</body>




      
</html>
